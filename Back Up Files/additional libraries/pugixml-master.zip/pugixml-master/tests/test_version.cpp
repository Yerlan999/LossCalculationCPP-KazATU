#include "../src/pugixml.hpp"

#if PUGIXML_VERSION != 1130
#error Unexpected pugixml version
#endif
